<?php
namespace anim;

class Animation
{

    public function __construct()
    {}
}


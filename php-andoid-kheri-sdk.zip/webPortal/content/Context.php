<?php
namespace content;

use app\Activity;

class Context extends Activity
{

    public function __construct()
    {
        parent::__construct();
    }

    public function onCreate()
    {}
}


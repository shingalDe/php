<?php
require_once 'app/Activity.php';
require_once 'os/Bundle.php';
require_once 'immo/Immo.php';
require_once 'immo/ImmoType.php';
require_once 'anim/Animation.php';

use anim\Animation;
use app\Activity;
use immo\Immo;
use immo\ImmoType;
use os\Bundle;


new class extends Activity{
    
#Override
protected function onCreate(Bundle $bun){
$anim = new Animation();
$this->setAnimation($anim);
$immo = new Immo($this);
$immo->setLift(true);
$immType = new ImmoType();
$immo->setImmoType(ImmoType::WOHNUNG);
echo $bun->getString("Kheri");

}
    
};

<?php
namespace os;

class Handler
{

    public function __construct()
    {}
}


<?php
namespace os;

class Vibrator
{

    public function __construct()
    {}
}


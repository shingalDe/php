<?php
namespace app;

class Notification
{

    public function __construct()
    {}
}


<?php
namespace app;

use content\Context;

class ProgressDialog extends Dialog
{

    public function __construct(Context $context)
    {
        parent::__construct($context);
    }
}


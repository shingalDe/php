<?php
namespace app;

class Alertdialog extends Dialog
{

    public function __construct()
    {}
}


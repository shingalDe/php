<?php
namespace app;

use content\Context;

class Dialog
{

    public function __construct(Context $context)
    {
        
    }
    
    public function show(){
        
    }
    public function cancel(){
        
    }
    public function dismiss(){
        
    }
}


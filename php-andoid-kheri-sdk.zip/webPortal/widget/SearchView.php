<?php
namespace widget;

use content\Context;

class SearchView extends EditText
{

    public function __construct(Context $context)
    {
        parent::__construct($context);
    }
}


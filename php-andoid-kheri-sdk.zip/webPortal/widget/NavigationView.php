<?php
namespace widget;

use content\Context;

class NavigationView extends LinearLayout
{

    public function __construct(Context $context)
    {
        parent::__construct($context);
    }
}


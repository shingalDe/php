<?php
namespace widget;


use content\Context;
use view\View;

class ImageView extends View
{

    public function __construct(Context $context)
    {
        parent::__construct($context);
    }
}


<?php
namespace widget;

use content\Context;

class DrawerLayout extends LinearLayout
{

    public function __construct(Context $context)
    {
        parent::__construct($context);
    }
}


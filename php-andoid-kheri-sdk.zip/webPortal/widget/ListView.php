<?php
namespace widget;

use content\Context;
use view\ViewGroup;

class ListView extends ViewGroup
{

    public function __construct(Context $context)
    {
        parent::__construct($context);
    }
}


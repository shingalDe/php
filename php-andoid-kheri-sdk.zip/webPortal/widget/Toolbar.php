<?php
namespace widget;

use content\Context;

class Toolbar extends TabLayout
{

    public function __construct(Context $context)
    {
        parent::__construct($context);
    }
}

